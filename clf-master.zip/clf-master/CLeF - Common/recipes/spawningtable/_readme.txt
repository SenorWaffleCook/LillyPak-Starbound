// This directory contains recipes for Creative Mode cheat mod's Spawner Box.
// You are free to delete its contents if you don't use Creative Mode.